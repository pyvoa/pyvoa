from pyvoa import front

front()
