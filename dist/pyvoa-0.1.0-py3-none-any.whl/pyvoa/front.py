def front():
    print("This is the front.")

def hello():
    print("Hello")

