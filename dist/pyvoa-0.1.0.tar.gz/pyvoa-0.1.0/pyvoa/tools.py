def mytool():
    print("this is my tool.")

